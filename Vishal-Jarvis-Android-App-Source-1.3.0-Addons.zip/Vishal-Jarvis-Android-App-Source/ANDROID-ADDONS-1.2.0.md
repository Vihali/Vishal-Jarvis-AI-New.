# Vishal Jarvis Android Add-ons 1.2.0

This additive update keeps `GeminiAccess.java`, the bundled `personality.txt`, and the 3D character engine source unchanged. It adds Android-side companion features and connects them to the existing `mobile_action` tool.

## Added
- Optional “Hey Vishal” wake phrase while the app is foregrounded. It is not a 24/7 background microphone. The user must enable it and grant microphone permission. It uses Android SpeechRecognizer with offline preference; availability depends on installed speech services/language data.
- Local user-approved memory (`remember`, `recall_memory`, `forget_memory`). Memory is stored in app-private SharedPreferences and injected as relevant context for text and Live conversations. Do not store passwords, PINs, API keys or financial secrets.
- Reminders through Android AlarmManager and notifications. Reminders are restored after reboot. Delivery may be delayed by Doze/battery controls; Android notification permission is required on Android 13+.
- Recent notification reading through an optional NotificationListenerService. User must explicitly enable Notification Access in Android Settings. Recent notification snippets stay in app-private storage and can be cleared with “clear notification history”.
- Screen lock through Android Device Admin after the user approves the system prompt. This app cannot bypass the Android lock screen or unlock the phone.
- Existing native actions remain available: open apps, browser/YouTube search, call via dialer, WhatsApp draft, flashlight and Wi-Fi settings.
- Offline mode means local memory/reminders and supported native actions remain available without Gemini connectivity. Gemini chat/Live and browser search require internet.
- Existing Android TTS and Gemini Live voice/personality remain in place.

## Safety and permissions
- Microphone, notification access and Device Admin are opt-in.
- Calls require the user to tap Call in the dialer. WhatsApp messages are drafts; the user taps Send.
- Wi-Fi opens Android Internet settings; the user changes the switch.
- No Accessibility Service, hidden UI automation, password capture, lock-screen bypass, or automatic message sending is added.

## Verification status
Source-level changes are packaged. This environment does not have the Android SDK/JDK setup required by the repository's Windows APK build script, so a signed APK and device-level behavior have not been verified here. Run the repository GitHub Actions build and test on a real Android device before relying on these features.
