export type MobileAction = { action: 'open_app'; app: string } | { action: 'search_youtube' | 'search_web'; query: string } | { action: 'whatsapp_message'; recipient: string; message: string } | { action: 'call_number'; phone: string } | { action: 'call_contact'; recipient: string } | { action: 'set_flashlight'; enabled: boolean } | { action: 'open_wifi_settings' } | { action: 'remember'; text: string } | { action: 'recall_memory' | 'forget_memory' | 'list_notifications' | 'clear_notifications' | 'open_notification_access' | 'lock_screen' } | { action: 'set_reminder'; title: string; when: number } | { action: 'set_volume' | 'set_brightness'; percent: number } | { action: 'battery_level' | 'open_whatsapp_accessibility' };
export const MOBILE_TOOL = {
  name: 'mobile_action',
  description: 'Perform supported Android actions: open apps, search web/YouTube, prepare WhatsApp drafts or send only after an explicit direct_send request and user-enabled WhatsApp Accessibility service, dial a supplied number directly after SIM selection, call a saved contact by name after SIM selection, report the exact Android battery percentage, switch the flashlight, open Wi-Fi settings, save/recall/delete local memories, schedule reminders, read or clear recent notifications after the user grants Notification Access, request screen lock through Android Device Admin, set media volume, adjust screen brightness after Android permission, or open notification access settings. Calls are placed through Android Telecom after SIM selection (when multiple SIMs exist) and CALL_PHONE permission. WhatsApp direct send requires the user to explicitly request direct_send and manually enable the dedicated Accessibility service in Android Settings; never send without that explicit request. Wi-Fi must be toggled by the user. Never invent recipients, times, numbers or successful actions. Never store passwords or secrets in memory.',
  parameters: { type: 'OBJECT', properties: {
    action: { type: 'STRING', enum: ['open_app', 'search_youtube', 'search_web', 'whatsapp_message', 'call_number', 'call_contact', 'set_flashlight', 'open_wifi_settings', 'remember', 'recall_memory', 'forget_memory', 'set_reminder', 'list_notifications', 'clear_notifications', 'open_notification_access', 'lock_screen', 'set_volume', 'set_brightness', 'battery_level', 'open_whatsapp_accessibility'] },
    app: { type: 'STRING', description: 'App name, such as WhatsApp (WP), YouTube or Chrome. Only for open_app.' },
    query: { type: 'STRING', description: 'The exact search requested by the user. Required for search actions.' },
    recipient: { type: 'STRING', description: 'Saved contact name as spoken, or a full international phone number with country code. Contacts are resolved locally.' },
    message: { type: 'STRING', description: 'Complete message the user requested. Ask for it if missing.' },
    direct_send: { type: 'BOOLEAN', description: 'True only when the user explicitly says to send the completed WhatsApp message directly now. Otherwise false.' },
    phone: { type: 'STRING', description: 'Phone number explicitly provided by the user, including country code when possible. Only for call_number.' },
    enabled: { type: 'BOOLEAN', description: 'Whether the flashlight should be turned on or off. Only for set_flashlight.' },
    text: { type: 'STRING', description: 'A non-sensitive fact or preference the user explicitly asks to remember. Never save passwords, PINs, API keys or financial secrets.' },
    title: { type: 'STRING', description: 'Reminder title.' },
    when: { type: 'NUMBER', description: 'Reminder trigger time as Unix epoch milliseconds. Ask the user for an unambiguous date and time before scheduling.' },
    percent: { type: 'INTEGER', description: 'Target percentage from 0 to 100 for media volume or screen brightness.' },
  }, required: ['action'] },
};
/** Exact local typed commands; Live voice uses structured Gemini function calls. */
export function parseMobileAction(input: string): MobileAction | null {
  const digits = (value: string) => value.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
  const text = digits(input.trim()).replace(/^(?:hey\s+)?(?:vishal\s+jarvis|vishal|roisal\s+jarvis|roisal|jarvis|myraa|myra|মায়া|মায়া)[,\s:]+/iu, '').replace(/^(?:please|can you|could you)\s+/i, '').trim();
  if (/^(?:আমার চার্জ কত(?: পারসেন্ট| শতাংশ)?(?: আছে)?|ফোনের চার্জ কত(?: পারসেন্ট| শতাংশ)?(?: আছে)?|আমার ফোনের চার্জ কত(?: পারসেন্ট| শতাংশ)?(?: আছে)?|battery(?: percentage| level)? কত|what(?:'s| is) my battery(?: percentage| level)?|battery percentage)$/iu.test(text)) return { action: 'battery_level' };
  if (/^(?:হোয়াটসঅ্যাপ direct send চালু করো|হোয়াটসঅ্যাপ অটোমেটিক send permission|enable whatsapp direct send|open whatsapp accessibility)$/iu.test(text)) return { action: 'open_whatsapp_accessibility' };
  if (/^(?:মনে রেখো|মনে রাখো|remember)\s+(.+)$/iu.test(text)) return { action: 'remember', text: text.replace(/^(?:মনে রেখো|মনে রাখো|remember)\s+/iu,'').trim() };
  if (/^(?:কি মনে রেখেছ|কী মনে রেখেছ|আমার memory দেখাও|show memories|recall memory)$/iu.test(text)) return { action: 'recall_memory' };
  if (/^(?:আমার memory মুছে দাও|সব memory ভুলে যাও|forget all memories|clear memories)$/iu.test(text)) return { action: 'forget_memory' };
  if (/^(?:notification দেখাও|নোটিফিকেশন দেখাও|show notifications|read notifications)$/iu.test(text)) return { action: 'list_notifications' };
  if (/^(?:notification history মুছে দাও|নোটিফিকেশন মুছে দাও|clear notification history)$/iu.test(text)) return { action: 'clear_notifications' };
  if (/^(?:notification access চালু করো|নোটিফিকেশন access খোলো|open notification access)$/iu.test(text)) return { action: 'open_notification_access' };
  if (/^(?:ফোন lock করো|ফোন লক করো|lock my phone|lock screen)$/iu.test(text)) return { action: 'lock_screen' };
  let level = /^(?:volume|ভলিউম)\s*(?:করো|set)?\s*(\d{1,3})\s*(?:percent|%|শতাংশ)?$/iu.exec(text); if (level) return { action: 'set_volume', percent: Number(level[1]) };
  level = /^(?:brightness|ব্রাইটনেস)\s*(?:করো|set)?\s*(\d{1,3})\s*(?:percent|%|শতাংশ)?$/iu.exec(text); if (level) return { action: 'set_brightness', percent: Number(level[1]) };
  const reminder = /^(?:remind me|মনে করিয়ে দিও|মনে করিয়ে দিও)\s+(.+?)\s+(?:at|সময়|সময়)\s+(\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2})$/iu.exec(text);
  if (reminder) { const when = new Date(reminder[2].replace(' ','T')).getTime(); if (Number.isFinite(when)) return { action: 'set_reminder', title: reminder[1].trim(), when }; }
  let call = /^(?:কল\s*(?:করো|কর|দাও)?|ফোন\s*করো|call(?:\s+to)?|dial)\s*[:,ঃ-]?\s*(?:এই\s+নম্বর(?:ে)?\s*)?([+0-9][0-9 ()-]{6,22})$/iu.exec(text) || /^([+0-9][0-9 ()-]{6,22})\s*(?:নম্বরে\s*)?(?:কল\s*করো|ফোন\s*করো)$/iu.exec(text);
  if (call) return { action: 'call_number', phone: call[1].trim() };
  if (/^(?:(?:ওয়াই|ওয়াই).?ফাই|wifi|wi-fi|ইন্টারনেট)(?:\s*(?:অন|চালু|on|enable))?\s*(?:করো|চালু করো|খোলো|open)?$/iu.test(text) || /^(?:(?:ওয়াই|ওয়াই).?ফাই|wifi|wi-fi)\s*(?:সেটিংস|settings)\s*(?:খোলো|open)?$/iu.test(text) || /^(?:turn\s+on\s+)?wi-?fi\s+(?:on|enable)$/i.test(text)) return { action: 'open_wifi_settings' };
  if (/^(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)\s*(?:অন|চালু|on|ওপেন|খোলো|open)(?:\s*করো)?$/iu.test(text) || /^(?:অন|চালু|ওপেন|open)\s*(?:করো\s*)?(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)$/iu.test(text) || /^turn\s+on\s+(?:the\s+)?flashlight$/i.test(text)) return { action: 'set_flashlight', enabled: true };
  if (/^(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)\s*(?:অফ|বন্ধ|off)(?:\s*করো)?$/iu.test(text) || /^(?:বন্ধ|অফ)\s*(?:করো\s*)?(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)$/iu.test(text) || /^turn\s+off\s+(?:the\s+)?flashlight$/i.test(text)) return { action: 'set_flashlight', enabled: false };
  let contactCall = /^(?:এই নাম্বারে থাকা )?(.+?)\s*(?:কে|কে)?\s*(?:কল|ফোন)\s*(?:করো|কর|দাও)$/iu.exec(text) || /^(?:কল|ফোন)\s*(?:করো|কর|দাও)\s+(.+?)(?:\s*কে)?$/iu.exec(text) || /^call\s+(.+)$/i.exec(text);
  if (contactCall && contactCall[1].trim() && !/^[+0-9][0-9 ()+-]*$/.test(contactCall[1].trim())) return { action: 'call_contact', recipient: contactCall[1].trim().replace(/\s+নামে$/, '') };
  call = /^(?:কল\s*(?:করো|কর|দাও)|ফোন\s*করো|call|dial)$/iu.exec(text);
  if (call) return null;
  let match = /^(?:open\s+)?(?:youtube|you tube)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+on\s+youtube$/i.exec(text);
  if (match) return { action: 'search_youtube', query: match[1].trim() };
  match = /^(?:open\s+)?(?:chrome|google chrome|browser)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+(?:on|in)\s+(?:chrome|google|browser)$/i.exec(text);
  if (match) return { action: 'search_web', query: match[1].trim() };
  const directSend = /(?:directly send|send directly|সরাসরি পাঠাও|ডাইরেক্টলি সেন্ড|direct send)/iu.test(text);
  const messageText = text.replace(/(?:এখনই\s*)?(?:directly send|send directly|সরাসরি পাঠাও|ডাইরেক্টলি সেন্ড|direct send)(?:\s+করো|\s+করে দাও)?/iu, '').trim();
  match = /^(?:message|msg|text)\s+(.+?)\s+(?:on|using)\s+(?:whatsapp|wp|wa)\s*:\s*(.+)$/is.exec(messageText) || /^(?:whatsapp|wp|wa)\s+(?:message|msg)(?:\s+to)?\s+(.+?)\s*:\s*(.+)$/is.exec(messageText);
  if (match) return { action: 'whatsapp_message', recipient: match[1].trim(), message: match[2].trim(), direct_send: directSend };
  const openText = text.replace(/[.!?।]+$/u, '');
  match = /^(?:open|launch)\s+([\p{L}\p{N}][\p{L}\p{N} ._-]{0,79})$/iu.exec(openText) || /^(whatsapp|wp|wa|youtube|chrome)\s+(?:kholo|khol do|open karo)$/i.exec(openText);
  if (match && !/\band\b/i.test(match[1])) return { action: 'open_app', app: match[1].trim() };
  return null;
}
