# Vishal Jarvis Android Add-ons 1.2.0

This additive update keeps `GeminiAccess.java`, the bundled `personality.txt`, and the 3D character engine source unchanged. It adds Android-side companion features and connects them to the existing `mobile_action` tool.

## Added
- Optional “Hey Vishal” wake phrase while the app is foregrounded. It is not a 24/7 background microphone. The user must enable it and grant microphone permission. It uses Android SpeechRecognizer with offline preference; availability depends on installed speech services/language data.
- Local user-approved memory (`remember`, `recall_memory`, `forget_memory`). Memory is stored in app-private SharedPreferences and injected as relevant context for text and Live conversations. Do not store passwords, PINs, API keys or financial secrets.
- Reminders through Android AlarmManager and notifications. Reminders are restored after reboot. Delivery may be delayed by Doze/battery controls; Android notification permission is required on Android 13+.
- Recent notification reading through an optional NotificationListenerService. User must explicitly enable Notification Access in Android Settings. Recent notification snippets stay in app-private storage and can be cleared with “clear notification history”.
- Screen lock through Android Device Admin after the user approves the system prompt. This app cannot bypass the Android lock screen or unlock the phone.
- Existing native actions remain available: open apps, browser/YouTube search, call via dialer, WhatsApp draft, flashlight and Wi-Fi settings.
- Offline mode means local memory/reminders and supported native actions remain available without Gemini connectivity. Gemini chat/Live and browser search require internet.
- Existing Android TTS and Gemini Live voice/personality remain in place.

## Safety and permissions
- Microphone, notification access and Device Admin are opt-in.
- Calls request Phone permission and place the call through Android Telecom; when multiple SIMs are available, the user chooses the SIM first.
- WhatsApp drafts remain the default. Direct send is an optional, one-shot Accessibility feature that requires explicit user wording and manual enablement in Android Settings; it checks both the exact message and recipient name before tapping Send.
- Wi-Fi opens Android Internet settings; the user changes the switch.
- No Accessibility Service, hidden UI automation, password capture, lock-screen bypass, or automatic message sending is added.

## Verification status
Source-level changes are packaged. This environment does not have the Android SDK/JDK setup required by the repository's Windows APK build script, so a signed APK and device-level behavior have not been verified here. Run the repository GitHub Actions build and test on a real Android device before relying on these features.


## Version 1.3.0 additions
- Battery percentage is read directly from Android's sticky battery broadcast.
- Calls use Android Telecom and show a SIM chooser when multiple call-capable SIM accounts are available. The app requests CALL_PHONE permission before placing the call.
- WhatsApp direct send is opt-in: the user must enable the dedicated Vishal Jarvis Accessibility service and explicitly request a direct send for the complete message. The service checks that the exact message is visible in the WhatsApp composer and taps Send once. The pending request expires after two minutes. Without this permission, only a draft is opened.
- Accessibility access is powerful and can expose on-screen content while enabled. Enable it only if you trust this feature; disable it in Android Accessibility settings whenever you do not need direct sending.
