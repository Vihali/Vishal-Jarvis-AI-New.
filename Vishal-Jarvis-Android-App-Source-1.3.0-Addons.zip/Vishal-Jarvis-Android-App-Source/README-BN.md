# Vishal Jarvis — Android App Source

এই ZIP-এ Android-এ চালানোর জন্য Vishal Jarvis-এর source code রয়েছে। আগের অ্যাপের Android chat, Gemini API, Live Voice, text-to-speech, Android actions, permissions, conversation history এবং settings flow বজায় রাখা হয়েছে। পরিবর্তন করা হয়েছে অ্যাপের নাম/assistant পরিচয় এবং 3D character: আগের অনুপস্থিত external character model-এর বদলে এখন Three.js দিয়ে তৈরি একটি নিজস্ব 3D male robot/android companion ব্যবহার করা হয়েছে।

## কী পরিবর্তন হয়েছে

- App display name: **Vishal Jarvis**
- Creator identity: **Vishal**; when asked who created it, the assistant identifies Vishal.
- Default language: **বাংলা (পশ্চিমবঙ্গ, ভারত)**; Banglish and English are understood.
- Phone calls: opens Android dialer with the user-provided number; user must review and tap Call. The app does not silently place calls.
- Assistant-এর পরিচয় ও chat/voice prompt: **Vishal Jarvis**
- App icon-এর letter mark: **VJ**
- 3D character: metallic armour, dark faceplate, cyan/blue glowing eyes ও chest core-সহ একটি robotic male companion
- Character-এর geometry source code-এর মধ্যেই তৈরি হয়। আলাদা PMX/VRM/GLB model, texture download বা third-party character asset প্রয়োজন নেই।
- Character-এর idle motion, pointer/look response, voice-reactive glow/mouth, Wave, Dance, Sit, Stand এবং Portrait/Full body controls রাখা হয়েছে।

## আগের Android features

Gemini text chat, Gemini Live voice transport, Android TTS, voice-related native integration, installed app open, Google/Chrome search, YouTube search, local contact lookup, WhatsApp message draft, explicit-number phone dialer (user confirms by tapping Call), settings, conversation history, API key storage এবং Live voice notification/floating controls-এর existing code অপরিবর্তিত রাখার চেষ্টা করা হয়েছে। WhatsApp message draft খোলে; ব্যবহারকারীকে WhatsApp-এ গিয়ে নিজে Send চাপতে হয়। এটি unrestricted phone control নয়।

## APK বানানো

এই build script Windows + PowerShell-এর জন্য। লাগবে:

1. Node.js এবং npm
2. JDK 21
3. Android SDK Platform 35
4. Android SDK Build Tools 35.0.0
5. PowerShell 7 (`pwsh`)

Project folder-এর ভিতরে PowerShell খুলে চালাও:

```powershell
npm install
pwsh -NoProfile -File scripts/build-android.ps1 -SdkRoot 'C:\path\to\android-sdk' -JavaRoot 'C:\path\to\jdk-21'
```

APK তৈরি হলে পাওয়া যাবে:

```text
artifacts/android/Vishal-Jarvis-1.1.0-private.apk
```

ফোনে USB debugging/ADB দিয়ে install:

```powershell
adb install -r artifacts/android/Vishal-Jarvis-1.1.0-private.apk
```

অথবা APK ফোনে কপি করে Android package installer দিয়ে install করা যাবে।

## ফোনে চালানোর শর্ত

- Android 8.0 / API 26 বা নতুন
- Android System WebView 100 বা নতুন
- OpenGL ES 3 support
- Chat ও Live voice-এর জন্য internet এবং নিজের Gemini API key/model access
- প্রয়োজন অনুযায়ী microphone, contacts এবং floating control permission

প্রথমবার app খুলে Settings-এ নিজের Gemini API key দাও। API key source code-এ রাখা নেই।

## গুরুত্বপূর্ণ সীমাবদ্ধতা ও পরীক্ষার অবস্থা

এই ZIP হলো source package, APK নয়। এই পরিবেশে npm dependencies install শেষ হয়নি; ফলে নতুন Vite/Android build সম্পন্ন বা physical Android phone-এ পরীক্ষা করা যায়নি। তাই source code-এ character ও branding পরিবর্তন করা হয়েছে, কিন্তু APK-টি এখনো build-verified বা device-tested বলে দাবি করা হচ্ছে না।

Android package ID `com.myraa.mobile`, native bridge নাম, preferences namespace এবং internal event identifiers ইচ্ছাকৃতভাবে আগের মতো রাখা হয়েছে যাতে existing native integration/settings data-র compatibility অকারণে না ভাঙে। Launcher-এ প্রদর্শিত app name কিন্তু Vishal Jarvis।

Build script local development signing key তৈরি করতে পারে; এটি private testing-এর জন্য, Play Store release signing key নয়।


## Android Add-ons 1.2.0

এই সংস্করণে মূল Gemini provider, মূল personality profile এবং 3D character engine না বদলে Android-side কিছু নতুন সুবিধা যোগ করা হয়েছে। বিস্তারিত সীমাবদ্ধতা `ANDROID-ADDONS-1.2.0.md` ফাইলে আছে।

- **Hey Vishal:** Settings থেকে চালু করলে অ্যাপ সামনে থাকা অবস্থায় wake phrase শোনে। এটি 24/7 background listening নয়; Speech Recognition-এর offline language data ফোনে থাকতে হবে।
- **Long-term memory:** “মনে রেখো …”, “কী মনে রেখেছ?” এবং “সব Memory ভুলে যাও” কমান্ড। Memory অ্যাপের private storage-এ থাকে; Password/PIN/API key সংরক্ষণ কোরো না।
- **Reminders:** Live voice-এ নির্দিষ্ট তারিখ ও সময় বলে Reminder তৈরি করা যায়। Notification permission লাগতে পারে; Android battery optimization delivery দেরি করাতে পারে।
- **Notification assistant:** প্রথমে “Notification access খোলো” বলে Android Settings-এ অনুমতি চালু করতে হবে; তারপর “Notification দেখাও” বললে সাম্প্রতিক Notification পড়বে।
- **Screen lock:** “ফোন Lock করো” বললে Android Device Admin অনুমতি চাইতে পারে। ফোন Unlock করার ক্ষমতা যোগ করা হয়নি; Android-এর PIN/Password/Fingerprint-ই থাকবে।
- **Offline mode:** Local memory, reminders এবং supported native phone actions ইন্টারনেট ছাড়াই চলতে পারে। Gemini chat/Live এবং browser search-এর জন্য internet দরকার।
- **Existing voice/personality:** বর্তমান TTS ও Gemini Live voice/personality অপরিবর্তিত রাখা হয়েছে।

Call ডায়ালারে খোলে, WhatsApp draft খোলে—ব্যবহারকারী নিজে নিশ্চিত করে Call/Send করবেন। Wi-Fi Android Internet Settings-এ খোলে; switch ব্যবহারকারী নিজে বদলাবেন।


### Version 1.3.0
- “আমার চার্জ কত পারসেন্ট?” বললে Android থেকে বর্তমান Battery percentage পড়বে।
- একাধিক SIM থাকলে কল করার আগে SIM বেছে নিতে বলবে; Phone permission দেওয়ার পর নির্বাচিত SIM দিয়ে কল শুরু করবে।
- WhatsApp-এ সরাসরি পাঠাতে হলে Accessibility Settings থেকে Vishal Jarvis-এর WhatsApp direct send service আলাদা করে Enable করতে হবে এবং প্রতিবার স্পষ্ট করে “ডাইরেক্টলি সেন্ড করে দাও” বলতে হবে। না হলে শুধু draft খুলবে।
- Accessibility permission শক্তিশালী; কাজ না থাকলে Android Settings থেকে বন্ধ রাখো।
