package com.myraa.mobile;

import android.Manifest;
import android.app.*;
import android.media.AudioManager;
import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.net.Uri;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.provider.Settings;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.telephony.*;
import android.telecom.TelecomManager;
import android.telecom.PhoneAccountHandle;
import android.telecom.PhoneAccount;
import android.os.Bundle;
import android.content.ComponentName;
import org.json.*;
import java.util.*;

/** Bounded Android actions; WhatsApp accessibility is one-shot and opt-in. */
public final class MobileActions {
  public static final int CONTACTS_REQUEST=88;
  public static final int TORCH_REQUEST=89;
  public static final int CALL_PERMISSION_REQUEST=92;
  public interface Result { void complete(String id,JSONObject result); }
  public interface Launcher { boolean installed(String pkg); Intent app(String label); boolean open(Intent intent); }
  public interface Contacts { boolean needsPermission(); List<Recipient> find(String name); }
  public static final class Recipient {
    public final String name,phone;
    public Recipient(String name,String phone){this.name=name;this.phone=phone;}
  }
  private final Activity activity;
  private final Result result;
  private final Launcher launcher;
  private final Contacts contacts;
  private final JarvisFeatures features;
  private Runnable pending;
  private String pendingId;
  private String pendingTorchId;
  private Boolean pendingTorchState;
  private String pendingCallId, pendingCallNumber, pendingCallName;
  private AlertDialog chooser;
  private String chooserId;
  private final Map<String,JSONObject> completed=new LinkedHashMap<>();
  public MobileActions(Activity activity,Result result) {
    this(activity,result,new Launcher(){
      public boolean installed(String pkg){try{activity.getPackageManager().getPackageInfo(pkg,0);return true;}catch(Exception e){return false;}}
      public Intent app(String label){
        PackageManager pm=activity.getPackageManager();Intent main=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo info:pm.queryIntentActivities(main,0))if(normalize(info.loadLabel(pm).toString()).equals(normalize(label))&&info.activityInfo.exported)
          return new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(info.activityInfo.packageName,info.activityInfo.name);
        return null;
      }
      public boolean open(Intent intent){try{activity.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));return true;}catch(ActivityNotFoundException|SecurityException e){return false;}}
    },new Contacts(){
      public boolean needsPermission(){return true;}
      public List<Recipient> find(String name){
        List<Recipient> found=new ArrayList<>();Set<String> seen=new HashSet<>();
        String escaped=name.replace("\\","\\\\").replace("%","\\%").replace("_","\\_");
        try(Cursor c=activity.getContentResolver().query(Phone.CONTENT_URI,new String[]{Phone.DISPLAY_NAME,Phone.NUMBER,Phone.NORMALIZED_NUMBER},Phone.DISPLAY_NAME+" LIKE ? ESCAPE '\\'",new String[]{"%"+escaped+"%"},Phone.DISPLAY_NAME+" ASC")){
          if(c!=null)while(c.moveToNext()&&found.size()<20){
            String raw=c.getString(2);if(raw==null||raw.isEmpty())raw=c.getString(1);
            String phone=international(raw,activity);if(phone!=null&&seen.add(phone))found.add(new Recipient(c.getString(0),phone));
          }
        }
        List<Recipient> exact=new ArrayList<>();for(Recipient r:found)if(normalize(r.name).equals(normalize(name)))exact.add(r);
        return exact.isEmpty()?found:exact;
      }
    });
  }
  public MobileActions(Activity activity,Result result,Launcher launcher,Contacts contacts){this.activity=activity;this.result=result;this.launcher=launcher;this.contacts=contacts;this.features=new JarvisFeatures(activity);}
  public static String normalize(String input){return input==null?"":input.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
  private static String international(String raw,Activity activity){
    if(raw==null)return null;String clean=raw.replaceAll("[ ()-]","");if(clean.startsWith("00"))clean="+"+clean.substring(2);
    if(clean.matches("\\+[1-9][0-9]{7,14}"))return clean.substring(1);
    String country="";try{country=activity.getSystemService(TelephonyManager.class).getNetworkCountryIso();}catch(Exception ignored){}
    if(country==null||country.length()!=2){String language=activity.getSharedPreferences("myraa.mobile.v1",0).getString("language","bn-IN");country=language.endsWith("IN")?"IN":"US";}
    String e164=PhoneNumberUtils.formatNumberToE164(raw,country.toUpperCase(Locale.ROOT));return e164==null?null:e164.substring(1);
  }
  public static Intent search(String target,String query){
    if(query==null||query.trim().isEmpty()||query.length()>1000)throw new IllegalArgumentException("Say what you want to search for.");
    Uri uri="youtube".equals(target)?Uri.parse("https://www.youtube.com/results").buildUpon().appendQueryParameter("search_query",query.trim()).build():Uri.parse("https://www.google.com/search").buildUpon().appendQueryParameter("q",query.trim()).build();
    return new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE);
  }
  public static Intent draft(String phone,String message,String pkg){
    if(phone==null||!phone.matches("[1-9][0-9]{7,14}")||message==null||message.trim().isEmpty()||message.length()>4000)throw new IllegalArgumentException("A valid recipient and message are required.");
    return new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+phone).buildUpon().appendQueryParameter("text",message).build()).setPackage(pkg);
  }
  private JSONObject status(String status,String message){JSONObject value=new JSONObject();try{value.put("status",status).put("message",message);}catch(JSONException ignored){}return value;}
  private void finish(String id,String status,String message){JSONObject value=status(status,message);completed.put(id,value);while(completed.size()>64)completed.remove(completed.keySet().iterator().next());result.complete(id,value);}
  public void execute(String id,String name,String raw){
    if(id==null||!id.matches("[A-Za-z0-9-]{1,80}"))return;
    if(completed.containsKey(id)){result.complete(id,completed.get(id));return;}
    if(!"mobile_action".equals(name)){finish(id,"unsupported","That mobile action is unavailable.");return;}
    try{
      JSONObject args=new JSONObject(raw);String action=args.optString("action");
      if("open_app".equals(action)){openApp(id,args.optString("app"));return;}
      if("search_youtube".equals(action)||"search_web".equals(action)){
        boolean youtube=action.equals("search_youtube");Intent intent=search(youtube?"youtube":"web",args.optString("query"));String pkg=youtube?"com.google.android.youtube":"com.android.chrome";
        if(launcher.installed(pkg))intent.setPackage(pkg);else if(youtube&&launcher.installed("com.android.chrome"))intent.setPackage("com.android.chrome");
        boolean opened=launcher.open(intent);if(!opened&&intent.getPackage()!=null)opened=launcher.open(new Intent(intent).setPackage(null));
        finish(id,opened?"opened":"unavailable",opened?(youtube?"YouTube":"Browser")+" search opened.":"No app can open this search on this device.");return;
      }
      if("whatsapp_message".equals(action)){message(id,args.optString("recipient"),args.optString("message"),args.optBoolean("direct_send",false));return;}
      if("battery_level".equals(action)){batteryLevel(id);return;}
      if("open_whatsapp_accessibility".equals(action)){openWhatsAppAccessibility(id);return;}
      if("call_number".equals(action)){dial(id,args.optString("phone"));return;}
      if("call_contact".equals(action)){callContact(id,args.optString("recipient"));return;}
      if("set_flashlight".equals(action)){setFlashlight(id,args.optBoolean("enabled",false));return;}
      if("open_wifi_settings".equals(action)){openWifiSettings(id);return;}
      if("set_volume".equals(action)){setVolume(id,args.optInt("percent",-1));return;}
      if("set_brightness".equals(action)){setBrightness(id,args.optInt("percent",-1));return;}
      if("remember".equals(action)){JSONObject r=features.remember(args.optString("text"));finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("recall_memory".equals(action)){JSONObject r=features.recall();finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("forget_memory".equals(action)){JSONObject r=features.forget();finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("set_reminder".equals(action)){JSONObject r=features.reminder(args.optString("title"),args.optLong("when",0));finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("list_notifications".equals(action)){JSONObject r=features.notifications();finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("clear_notifications".equals(action)){JSONObject r=features.clearNotifications();finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("open_notification_access".equals(action)){JSONObject r=features.openNotificationAccess();finish(id,r.optString("status","failed"),r.optString("message"));return;}
      if("lock_screen".equals(action)){JSONObject r=features.lockScreen();finish(id,r.optString("status","failed"),r.optString("message"));return;}
      finish(id,"unsupported","Supported actions include app opening, web search, calls, WhatsApp drafts, flashlight, Wi-Fi settings, volume, brightness, local memory, reminders, notification access and screen lock.");
    }catch(IllegalArgumentException e){finish(id,"invalid",e.getMessage());}catch(Exception e){finish(id,"failed","Android could not complete this action. Nothing was sent.");}
  }
  private void batteryLevel(String id){
    try { Intent battery=activity.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); if(battery==null){finish(id,"unavailable","Battery তথ্য পাওয়া যাচ্ছে না।");return;} int level=battery.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL,-1), scale=battery.getIntExtra(android.os.BatteryManager.EXTRA_SCALE,-1); if(level<0||scale<=0){finish(id,"unavailable","Battery percentage পড়া যাচ্ছে না।");return;} int pct=Math.round(level*100f/scale); boolean charging=battery.getIntExtra(android.os.BatteryManager.EXTRA_STATUS,-1)==android.os.BatteryManager.BATTERY_STATUS_CHARGING || battery.getIntExtra(android.os.BatteryManager.EXTRA_STATUS,-1)==android.os.BatteryManager.BATTERY_STATUS_FULL; finish(id,"ok","তোমার ফোনের বর্তমান Battery " + pct + "%" + (charging?" এবং চার্জ হচ্ছে।":"।")); } catch(Exception e){finish(id,"failed","Battery percentage পড়া যায়নি।");}
  }
  private boolean whatsappAccessibilityEnabled(){
    String enabled=Settings.Secure.getString(activity.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); if(enabled==null)return false; String target=new ComponentName(activity,WhatsAppSendAccessibilityService.class).flattenToString(); for(String item:enabled.split(":")) if(target.equalsIgnoreCase(item))return true; return false;
  }
  private void openWhatsAppAccessibility(String id){ try{activity.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));finish(id,"settings_opened","Android Accessibility settings খুলেছি। Vishal Jarvis WhatsApp direct send চালু করতে চাইলে এখান থেকে পরিষেবাটি নিজে Enable করো।");}catch(Exception e){finish(id,"unavailable","Accessibility settings খোলা যায়নি। Android Settings থেকে Accessibility খোলো।");}}
  private void setVolume(String id,int percent){
    if(percent<0||percent>100){finish(id,"invalid","Volume 0 থেকে 100 শতাংশের মধ্যে বলো।");return;}
    try{AudioManager audio=(AudioManager)activity.getSystemService(Context.AUDIO_SERVICE);int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);audio.setStreamVolume(AudioManager.STREAM_MUSIC,Math.round(max*percent/100f),0);finish(id,"updated","Media volume "+percent+" শতাংশ করেছি।");}
    catch(Exception e){finish(id,"failed","Volume পরিবর্তন করা যায়নি।");}
  }
  private void setBrightness(String id,int percent){
    if(percent<0||percent>100){finish(id,"invalid","Brightness 0 থেকে 100 শতাংশের মধ্যে বলো।");return;}
    try{
      if(!Settings.System.canWrite(activity)){Intent access=new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+activity.getPackageName()));activity.startActivity(access);finish(id,"permission_required","Brightness বদলাতে Android-এর Modify system settings অনুমতি চালু করো, তারপর আবার বলো।");return;}
      Settings.System.putInt(activity.getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE,Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
      Settings.System.putInt(activity.getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,Math.round(percent*255f/100f));finish(id,"updated","Screen brightness "+percent+" শতাংশ করেছি।");
    }catch(Exception e){finish(id,"failed","Brightness পরিবর্তন করা যায়নি।");}
  }
  private void callContact(String id,String recipient){
    if(recipient==null||recipient.trim().isEmpty()||recipient.length()>100){finish(id,"invalid","যাঁকে কল করতে চাও, তাঁর সেভ করা নামটি বলো।");return;}
    if(recipient.trim().matches("\\+?[0-9 ()-]+")){dial(id,recipient);return;}
    if(contacts.needsPermission()&&activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
      if(pending!=null||pendingTorchId!=null){finish(id,"busy","আগের অনুমতির কাজটি শেষ করো।");return;}
      pendingId=id;pending=()->callContact(id,recipient);activity.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},CONTACTS_REQUEST);return;
    }
    List<Recipient> matches=contacts.find(recipient.trim());
    if(matches.isEmpty()){finish(id,"not_found","এই নামে ফোন নম্বর-সহ কোনো Contact পেলাম না। Contacts permission চালু আছে কি না দেখো, অথবা পুরো নামটি বলো।");return;}
    if(matches.size()==1){dialContact(id,matches.get(0));return;}
    if(chooser!=null){finish(id,"busy","আগের Contact নির্বাচনটি আগে শেষ করো।");return;}
    String[] labels=new String[matches.size()];for(int i=0;i<labels.length;i++)labels[i]=matches.get(i).name+" · +"+matches.get(i).phone;
    chooserId=id;chooser=new AlertDialog.Builder(activity).setTitle("কাকে কল করবে — "+recipient+"?").setItems(labels,(d,index)->{chooser=null;dialContact(id,matches.get(index));})
      .setNegativeButton("বাতিল",(d,w)->{chooser=null;finish(id,"cancelled","কল বাতিল করা হয়েছে।");}).setOnCancelListener(d->{chooser=null;finish(id,"cancelled","কল বাতিল করা হয়েছে।");}).show();
  }
  private void dialContact(String id,Recipient person){ placeCallWithSim(id,person.phone,person.name); }
  private void setFlashlight(String id,boolean enabled){
    if(activity.checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
      if(pending!=null||pendingTorchId!=null){finish(id,"busy","আগের অনুমতির কাজটি শেষ করো।");return;}
      pendingTorchId=id;pendingTorchState=enabled;activity.requestPermissions(new String[]{Manifest.permission.CAMERA},TORCH_REQUEST);return;
    }
    applyFlashlight(id,enabled);
  }
  private void applyFlashlight(String id,boolean enabled){
    try{
      CameraManager manager=(CameraManager)activity.getSystemService(Context.CAMERA_SERVICE);String cameraId=null;
      for(String candidate:manager.getCameraIdList())if(manager.getCameraCharacteristics(candidate).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)==Boolean.TRUE){cameraId=candidate;break;}
      if(cameraId==null){finish(id,"unavailable","এই ফোনে Flashlight হার্ডওয়্যার পাওয়া যায়নি।");return;}
      manager.setTorchMode(cameraId,enabled);finish(id,"torch_changed",enabled?"Flashlight অন করেছি।":"Flashlight বন্ধ করেছি।");
    }catch(SecurityException e){finish(id,"permission_required","Flashlight ব্যবহারের জন্য Camera permission দিতে হবে।");}
    catch(Exception e){finish(id,"failed","Flashlight পরিবর্তন করা যায়নি। অন্য কোনো অ্যাপ ক্যামেরা ব্যবহার করছে কি না দেখো।");}
  }
  private void openWifiSettings(String id){
    Intent intent=Build.VERSION.SDK_INT>=29?new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY):new Intent(Settings.ACTION_WIFI_SETTINGS);
    boolean opened=launcher.open(intent);if(!opened&&Build.VERSION.SDK_INT>=29)opened=launcher.open(new Intent(Settings.ACTION_WIFI_SETTINGS));finish(id,opened?"settings_opened":"unavailable",opened?"Wi-Fi ও Internet প্যানেল খুলেছি। Android-এর নিয়মে এখানে Wi-Fi সুইচটি তোমাকেই অন করতে হবে।":"এই ফোনে Wi-Fi সেটিংস খোলা যায়নি।");
  }
  private void dial(String id,String raw){
    String number=raw==null?"":raw.trim().replaceAll("[\\s()-]",""); if(number.startsWith("00"))number="+"+number.substring(2);
    if(!number.matches("\\+?[0-9]{7,15}")){finish(id,"invalid","সঠিক ফোন নম্বরটি দেশের কোড-সহ বলুন।");return;}
    placeCallWithSim(id,number.replace("+",""),number);
  }
  private void placeCallWithSim(String id,String phone,String displayName){
    if(activity.checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){pendingCallId=id;pendingCallNumber=phone;pendingCallName=displayName;activity.requestPermissions(new String[]{Manifest.permission.CALL_PHONE},CALL_PERMISSION_REQUEST);return;}
    try{
      TelecomManager telecom=(TelecomManager)activity.getSystemService(Context.TELECOM_SERVICE);
      List<PhoneAccountHandle> accounts=telecom==null?Collections.emptyList():telecom.getCallCapablePhoneAccounts();
      if(accounts!=null && accounts.size()>1){
        String[] labels=new String[accounts.size()]; for(int i=0;i<accounts.size();i++){PhoneAccount a=telecom.getPhoneAccount(accounts.get(i)); CharSequence label=a==null?null:a.getLabel(); labels[i]=(i==0?"SIM 1":"SIM "+(i+1))+(label==null?"":" · "+label);}
        final String num=phone, name=displayName; chooserId=id; chooser=new AlertDialog.Builder(activity).setTitle("কোন SIM দিয়ে কল করবে?").setItems(labels,(d,index)->{chooser=null;chooserId=null;placeCall(id,num,name,accounts.get(index));}).setNegativeButton("বাতিল",(d,w)->{chooser=null;chooserId=null;finish(id,"cancelled","কল বাতিল করা হয়েছে।");}).setOnCancelListener(d->{chooser=null;chooserId=null;finish(id,"cancelled","কল বাতিল করা হয়েছে।");}).show(); return;
      }
      placeCall(id,phone,displayName,accounts!=null&&!accounts.isEmpty()?accounts.get(0):null);
    }catch(SecurityException e){finish(id,"permission_required","সিম নির্বাচন করতে Phone permission দরকার। Android Settings থেকে অনুমতি দিয়ে আবার বলো।");}catch(Exception e){finish(id,"failed","কল শুরু করা যায়নি। কোনো কল করা হয়নি।");}
  }
  private void placeCall(String id,String phone,String displayName,PhoneAccountHandle account){
    try{TelecomManager telecom=(TelecomManager)activity.getSystemService(Context.TELECOM_SERVICE); android.os.Bundle extras=new android.os.Bundle(); if(account!=null)extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE,account); telecom.placeCall(Uri.fromParts("tel",phone,null),extras); finish(id,"call_started",displayName+"-কে কল শুরু করেছি। Android-এর Call UI-তে কলের অবস্থা দেখো।");}
    catch(SecurityException e){finish(id,"permission_required","Call permission না থাকায় কল করা যায়নি।");}catch(Exception e){finish(id,"failed","কল শুরু করা যায়নি। কোনো কল করা হয়নি।");}
  }
  public void callPermissionResult(){String id=pendingCallId,num=pendingCallNumber,name=pendingCallName;pendingCallId=null;pendingCallNumber=null;pendingCallName=null;if(id==null)return;if(activity.checkSelfPermission(Manifest.permission.CALL_PHONE)==PackageManager.PERMISSION_GRANTED)placeCallWithSim(id,num,name);else finish(id,"permission_required","সরাসরি কলের জন্য Phone permission অনুমতি দাও, তারপর আবার চেষ্টা করো।");}
  private void openApp(String id,String input){
    String app=normalize(input);if(app.isEmpty()||app.length()>100){finish(id,"invalid","Say which app to open.");return;}
    Intent intent=null;
    if(Arrays.asList("wp","wa","whats app","whatsapp","व्हाट्सएप").contains(app)){
      String pkg=whatsapp();if(pkg==null){finish(id,"not_installed","WhatsApp is not installed on this Android device.");return;}intent=activity.getPackageManager().getLaunchIntentForPackage(pkg);if(intent==null)intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/")).setPackage(pkg);
    }else if(Arrays.asList("youtube","you tube","यूट्यूब").contains(app))intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com")).setPackage(launcher.installed("com.google.android.youtube")?"com.google.android.youtube":launcher.installed("com.android.chrome")?"com.android.chrome":null);
    else if(Arrays.asList("chrome","google chrome","browser","क्रोम").contains(app))intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")).setPackage(launcher.installed("com.android.chrome")?"com.android.chrome":null);
    else intent=launcher.app(input);
    if(intent==null){finish(id,"not_installed","No installed app matches that name.");return;}
    boolean opened=launcher.open(intent);finish(id,opened?"opened":"unavailable",opened?"Opened "+input+".":"Android could not open "+input+".");
  }
  private String whatsapp(){return launcher.installed("com.whatsapp")?"com.whatsapp":launcher.installed("com.whatsapp.w4b")?"com.whatsapp.w4b":null;}
  private void message(String id,String recipient,String text,boolean directSend){
    if(whatsapp()==null){finish(id,"not_installed","WhatsApp is not installed on this Android device.");return;}
    if(recipient.trim().isEmpty()||recipient.length()>100||text.trim().isEmpty()||text.length()>4000){finish(id,"invalid","Tell me the recipient and the complete message.");return;}
    if(recipient.trim().matches("\\+?[0-9 ()-]+")){
      String phone=recipient.replaceAll("[ ()+-]","");if(phone.startsWith("00"))phone=phone.substring(2);boolean international=recipient.trim().startsWith("+")||recipient.trim().startsWith("00")||phone.length()>=11;if(!international||!phone.matches("[1-9][0-9]{7,14}")){finish(id,"invalid","Include the country code in the recipient phone number, for example +91.");return;}
      openDraft(id,new Recipient(recipient,phone),text,directSend);return;
    }
    if(contacts.needsPermission()&&activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
      if(pending!=null||pendingTorchId!=null){finish(id,"busy","Finish the current permission request first.");return;}
      pendingId=id;pending=()->message(id,recipient,text,directSend);activity.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},CONTACTS_REQUEST);return;
    }
    List<Recipient> matches=contacts.find(recipient.trim());
    if(matches.isEmpty()){finish(id,"not_found","No matching contact with a usable phone number was found. Give the full saved name or an international phone number.");return;}
    if(matches.size()==1){openDraft(id,matches.get(0),text,directSend);return;}
    if(chooser!=null){finish(id,"busy","Choose the recipient from the current list first.");return;}
    String[] labels=new String[matches.size()];for(int i=0;i<labels.length;i++)labels[i]=matches.get(i).name+" · +"+matches.get(i).phone;
    chooserId=id;chooser=new AlertDialog.Builder(activity).setTitle("Which "+recipient+"?").setItems(labels,(d,index)->{chooser=null;openDraft(id,matches.get(index),text,directSend);})
      .setNegativeButton("Cancel",(d,w)->{chooser=null;finish(id,"cancelled","Message cancelled. Nothing was sent.");}).setOnCancelListener(d->{chooser=null;finish(id,"cancelled","Message cancelled. Nothing was sent.");}).show();
  }
  private void openDraft(String id,Recipient person,String text,boolean directSend){
    if(directSend && !whatsappAccessibilityEnabled()){
      prefsForActions().edit().remove("wa_pending_direct_send").apply();
      openWhatsAppAccessibility(id);
      return;
    }
    if(directSend){ try{prefsForActions().edit().putString("wa_pending_direct_send",new JSONObject().put("phone",person.phone).put("recipient",person.name).put("message",text).put("created",System.currentTimeMillis()).toString()).apply();}catch(Exception e){finish(id,"failed","Direct send প্রস্তুত করা যায়নি। কিছু পাঠানো হয়নি।");return;} }
    boolean opened=launcher.open(draft(person.phone,text,whatsapp()));
    if(!opened && directSend) prefsForActions().edit().remove("wa_pending_direct_send").apply();
    finish(id,opened?(directSend?"direct_send_queued":"draft_opened"):"unavailable",opened?(directSend?"WhatsApp খুলেছি। Accessibility service চালু থাকলে নির্দিষ্ট message composer-এ মিল পেলেই Send একবার চাপবে; পাঠানোর আগে WhatsApp-এ recipient ও message মিলিয়ে নাও।":"WhatsApp draft opened for "+person.name+". Review it and tap Send in WhatsApp; Vishal Jarvis has not sent it."):"WhatsApp could not open this recipient. Nothing was sent.");
  }
  private android.content.SharedPreferences prefsForActions(){return activity.getSharedPreferences("vishal.jarvis.features",Context.MODE_PRIVATE); }
  public void permissionResult(){Runnable retry=pending;String id=pendingId;pending=null;pendingId=null;if(retry==null)return;if(activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED)retry.run();else finish(id,"permission_required","Contacts access was denied. Allow Contacts permission in Android app settings, then try again.");}
  public void torchPermissionResult(){String id=pendingTorchId;Boolean enabled=pendingTorchState;pendingTorchId=null;pendingTorchState=null;if(id==null||enabled==null)return;if(activity.checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)applyFlashlight(id,enabled);else finish(id,"permission_required","Flashlight ব্যবহারের জন্য Camera permission অনুমতি দাও। Android Settings থেকে Vishal Jarvis-এর Camera permission চালু করে আবার চেষ্টা করো।");}
  public void cancel(String id){if(id==null||!id.matches("[A-Za-z0-9-]{1,80}"))return;if(completed.containsKey(id))return;if(id.equals(pendingId)){pending=null;pendingId=null;}if(id.equals(pendingTorchId)){pendingTorchId=null;pendingTorchState=null;}if(id.equals(chooserId)&&chooser!=null){chooser.dismiss();chooser=null;chooserId=null;}finish(id,"cancelled","Action cancelled. Nothing was sent.");}
  public void close(){pending=null;pendingId=null;pendingTorchId=null;pendingTorchState=null;pendingCallId=null;pendingCallNumber=null;pendingCallName=null;if(chooser!=null){chooser.dismiss();chooser=null;}}
}
