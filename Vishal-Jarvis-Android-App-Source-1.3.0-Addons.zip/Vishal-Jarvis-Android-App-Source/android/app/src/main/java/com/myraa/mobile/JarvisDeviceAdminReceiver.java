package com.myraa.mobile;
import android.app.admin.DeviceAdminReceiver;
public final class JarvisDeviceAdminReceiver extends DeviceAdminReceiver {}
