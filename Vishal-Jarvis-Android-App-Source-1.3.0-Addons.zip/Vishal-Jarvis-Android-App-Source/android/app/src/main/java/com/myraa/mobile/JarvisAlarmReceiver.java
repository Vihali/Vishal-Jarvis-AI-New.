package com.myraa.mobile;
import android.app.*;
import android.content.*;
import android.os.Build;

public final class JarvisAlarmReceiver extends BroadcastReceiver {
  public static final String ACTION_REMINDER="com.myraa.mobile.REMINDER";
  @Override public void onReceive(Context context,Intent intent) {
    if(intent==null || !ACTION_REMINDER.equals(intent.getAction())) return;
    String reminderId=intent.getStringExtra("id");
    try {
      android.content.SharedPreferences prefs=context.getSharedPreferences("vishal.jarvis.features",Context.MODE_PRIVATE);
      org.json.JSONArray old=new org.json.JSONArray(prefs.getString("scheduled_reminders","[]"));org.json.JSONArray keep=new org.json.JSONArray();
      for(int i=0;i<old.length();i++){org.json.JSONObject item=old.getJSONObject(i);if(!item.optString("id").equals(reminderId))keep.put(item);}
      prefs.edit().putString("scheduled_reminders",keep.toString()).apply();
    }catch(Exception ignored){}
    NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
    if(nm==null)return;
    if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("jarvis_reminders","Vishal Jarvis reminders",NotificationManager.IMPORTANCE_HIGH));
    Intent open=new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pi=PendingIntent.getActivity(context,7,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    String title=intent.getStringExtra("title"); if(title==null || title.trim().isEmpty())title="তোমার Reminder";
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"jarvis_reminders"):new Notification.Builder(context);
    b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Vishal Jarvis · Reminder").setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title)).setAutoCancel(true).setContentIntent(pi);
    nm.notify((intent.getStringExtra("id")==null?title:intent.getStringExtra("id")).hashCode(),b.build());
  }
}
