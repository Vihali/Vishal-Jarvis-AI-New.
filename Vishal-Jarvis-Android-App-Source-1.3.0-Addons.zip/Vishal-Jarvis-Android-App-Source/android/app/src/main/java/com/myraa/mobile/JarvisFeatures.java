package com.myraa.mobile;

import android.app.*;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import org.json.*;
import java.util.*;

/** Additive local companion features. Does not modify the Gemini provider or avatar runtime. */
public final class JarvisFeatures {
  private static final String PREFS = "vishal.jarvis.features";
  private final Activity activity;
  public JarvisFeatures(Activity activity) { this.activity = activity; }
  private android.content.SharedPreferences prefs() { return activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
  private JSONObject result(String status, String message) { JSONObject o=new JSONObject(); try{o.put("status",status).put("message",message);}catch(JSONException ignored){} return o; }
  public JSONObject remember(String value) {
    if(value==null || value.trim().isEmpty() || value.length()>1000) return result("invalid","কী মনে রাখতে হবে সেটা সংক্ষেপে বলো।");
    try {
      JSONArray old=new JSONArray(prefs().getString("memories","[]")); JSONArray next=new JSONArray();
      for(int i=Math.max(0,old.length()-38);i<old.length();i++) next.put(old.get(i));
      next.put(new JSONObject().put("text",value.trim()).put("at",System.currentTimeMillis()));
      prefs().edit().putString("memories",next.toString()).apply();
      return result("saved","মনে রাখলাম: "+value.trim());
    } catch(Exception e){return result("failed","Memory সংরক্ষণ করা যায়নি।");}
  }
  public JSONObject recall() {
    try { JSONArray a=new JSONArray(prefs().getString("memories","[]")); if(a.length()==0)return result("empty","এখনও কোনো Memory সংরক্ষণ করা হয়নি।"); StringBuilder b=new StringBuilder("তোমার সংরক্ষিত Memory:\n"); for(int i=0;i<a.length();i++) b.append("• ").append(a.getJSONObject(i).optString("text")).append("\n"); return result("ok",b.toString()); }
    catch(Exception e){return result("failed","Memory পড়া যায়নি।");}
  }
  public JSONObject forget() { prefs().edit().remove("memories").apply(); return result("cleared","সংরক্ষিত Memory মুছে দিয়েছি।"); }
  public String memoryContext() {
    try { JSONArray a=new JSONArray(prefs().getString("memories","[]")); StringBuilder b=new StringBuilder(); for(int i=Math.max(0,a.length()-20);i<a.length();i++) b.append("- ").append(a.getJSONObject(i).optString("text")).append("\n"); return b.toString(); }
    catch(Exception e){return "";}
  }
  public JSONObject reminder(String title,long when) {
    if(title==null || title.trim().isEmpty() || title.length()>160) return result("invalid","Reminder-এর নাম বলো।");
    long now=System.currentTimeMillis(); if(when<now+5000 || when>now+366L*24*60*60*1000) return result("invalid","Reminder-এর সময় আগামী ৫ সেকেন্ড থেকে এক বছরের মধ্যে হতে হবে।");
    if(Build.VERSION.SDK_INT>=33 && activity.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
      activity.requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},91);
      return result("permission_required","Reminder notification দেখাতে Notification permission দরকার। অনুমতি দেওয়ার পর Reminder command-টি আবার বলো।");
    }
    try {
      String id=UUID.randomUUID().toString(); Intent intent=new Intent(activity,JarvisAlarmReceiver.class).setAction(JarvisAlarmReceiver.ACTION_REMINDER).putExtra("id",id).putExtra("title",title.trim());
      PendingIntent pi=PendingIntent.getBroadcast(activity,id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      AlarmManager alarms=(AlarmManager)activity.getSystemService(Context.ALARM_SERVICE);
      if(alarms==null)return result("unavailable","Android Alarm service পাওয়া যাচ্ছে না।");
      if(Build.VERSION.SDK_INT>=23) alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else alarms.set(AlarmManager.RTC_WAKEUP,when,pi);
      JSONArray scheduled=new JSONArray(prefs().getString("scheduled_reminders","[]"));
      scheduled.put(new JSONObject().put("id",id).put("title",title.trim()).put("when",when));
      prefs().edit().putString("scheduled_reminders",scheduled.toString()).apply();
      return result("scheduled","Reminder সেট হয়েছে: "+title.trim()+"। নির্ধারিত সময়ে Android notification দেখাবে।");
    } catch(Exception e){return result("failed","Reminder সেট করা যায়নি।");}
  }
  public JSONObject clearNotifications() { prefs().edit().remove("recent_notifications").apply(); return result("cleared","সাম্প্রতিক Notification-এর স্থানীয় কপি মুছে দিয়েছি।"); }
  public JSONObject notifications() {
    if(!NotificationAccessService.enabled(activity)) return result("permission_required","Notification পড়তে Android Settings থেকে Vishal Jarvis-এর Notification access চালু করতে হবে।");
    String raw=activity.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("recent_notifications","[]");
    try { JSONArray a=new JSONArray(raw); if(a.length()==0)return result("empty","নতুন কোনো Notification সংরক্ষিত নেই।"); StringBuilder b=new StringBuilder("সাম্প্রতিক Notification:\n"); for(int i=0;i<a.length();i++){JSONObject n=a.getJSONObject(i);b.append("• ").append(n.optString("app")).append(": ").append(n.optString("title")).append(" — ").append(n.optString("text")).append("\n");} return result("ok",b.toString()); }
    catch(Exception e){return result("failed","Notification পড়া যায়নি।");}
  }
  public JSONObject openNotificationAccess() { try { activity.startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); return result("opened","Notification access settings খুলেছি। Vishal Jarvis-কে অনুমতি দিলে তবেই Notification পড়তে পারবে।"); } catch(Exception e){return result("unavailable","Notification access settings খোলা যায়নি।");} }
  public JSONObject lockScreen() {
    try {
      ComponentName admin=new ComponentName(activity,JarvisDeviceAdminReceiver.class);
      DevicePolicyManager dpm=(DevicePolicyManager)activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
      if(dpm!=null && dpm.isAdminActive(admin)){dpm.lockNow();return result("locked","ফোন Lock করার নির্দেশ পাঠানো হয়েছে।");}
      Intent request=new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,admin).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"Vishal Jarvis needs Device Admin only to lock this phone when you explicitly ask.");
      activity.startActivity(request); return result("permission_required","ফোন Lock করার আগে Android-এর Device Admin অনুমতি চালু করো। তারপর আবার ‘ফোন Lock করো’ বলো।");
    } catch(Exception e){return result("failed","ফোন Lock করা যায়নি। Android Security সেটিংস পরীক্ষা করো।");}
  }
}
