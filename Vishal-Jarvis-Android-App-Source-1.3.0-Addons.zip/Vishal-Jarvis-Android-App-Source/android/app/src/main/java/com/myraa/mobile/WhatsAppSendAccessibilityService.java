package com.myraa.mobile;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.Locale;

/** One-shot, user-enabled WhatsApp send helper. It only acts on an explicitly queued message. */
public final class WhatsAppSendAccessibilityService extends AccessibilityService {
  private static final String PREFS = "vishal.jarvis.features";
  private long lastAttempt;
  @Override public void onAccessibilityEvent(AccessibilityEvent event) {
    if (event == null || event.getPackageName() == null) return;
    String pkg = event.getPackageName().toString();
    if (!"com.whatsapp".equals(pkg) && !"com.whatsapp.w4b".equals(pkg)) return;
    if (SystemClock.elapsedRealtime() - lastAttempt < 700) return;
    SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
    String raw = prefs.getString("wa_pending_direct_send", null);
    if (raw == null) return;
    try {
      JSONObject pending = new JSONObject(raw);
      long created = pending.optLong("created", 0);
      if (created == 0 || System.currentTimeMillis() - created > 120000) { prefs.edit().remove("wa_pending_direct_send").apply(); return; }
      String expected = pending.optString("message", "").trim();
      String expectedRecipient = pending.optString("recipient", "").trim();
      if (expected.isEmpty() || expectedRecipient.isEmpty()) return;
      AccessibilityNodeInfo root = getRootInActiveWindow();
      if (root == null) return;
      if (!containsExactMessage(root, expected) || !containsRecipient(root, expectedRecipient)) return;
      AccessibilityNodeInfo send = findSend(root);
      if (send == null || !send.isEnabled()) return;
      lastAttempt = SystemClock.elapsedRealtime();
      boolean clicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
      if (clicked) {
        prefs.edit().remove("wa_pending_direct_send").apply();
        Toast.makeText(this, "Vishal Jarvis: WhatsApp message sent", Toast.LENGTH_SHORT).show();
      }
    } catch (Exception ignored) { }
  }
  private boolean containsExactMessage(AccessibilityNodeInfo node, String expected) {
    if (node == null) return false;
    CharSequence text = node.getText();
    if (text != null && expected.contentEquals(text.toString().trim())) return true;
    for (int i=0; i<node.getChildCount(); i++) if (containsExactMessage(node.getChild(i), expected)) return true;
    return false;
  }
  private boolean containsRecipient(AccessibilityNodeInfo node, String expected) {
    if (node == null) return false;
    CharSequence text=node.getText(), desc=node.getContentDescription();
    if (text != null && expected.equalsIgnoreCase(text.toString().trim())) return true;
    if (desc != null && expected.equalsIgnoreCase(desc.toString().trim())) return true;
    for (int i=0; i<node.getChildCount(); i++) if (containsRecipient(node.getChild(i), expected)) return true;
    return false;
  }
  private AccessibilityNodeInfo findSend(AccessibilityNodeInfo node) {
    if (node == null) return null;
    CharSequence t=node.getText(), d=node.getContentDescription();
    String value=((t==null?"":t.toString())+" "+(d==null?"":d.toString())).trim().toLowerCase(Locale.ROOT);
    if ((value.equals("send") || value.equals("send message") || value.equals("পাঠান") || value.equals("প্রেরণ") || value.equals("भेजें")) && node.isClickable()) return node;
    for (int i=0; i<node.getChildCount(); i++) { AccessibilityNodeInfo found=findSend(node.getChild(i)); if(found!=null)return found; }
    return null;
  }
  @Override public void onInterrupt() { }
}
