package com.myraa.mobile;
import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.*;

public final class JarvisBootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context,Intent intent) {
    if(intent==null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()))return;
    try {
      JSONArray a=new JSONArray(context.getSharedPreferences("vishal.jarvis.features",Context.MODE_PRIVATE).getString("scheduled_reminders","[]"));
      AlarmManager alarms=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);long now=System.currentTimeMillis();
      for(int i=0;i<a.length();i++){JSONObject item=a.getJSONObject(i);long when=item.optLong("when",0);if(when<=now)continue;
        String id=item.optString("id");Intent fire=new Intent(context,JarvisAlarmReceiver.class).setAction(JarvisAlarmReceiver.ACTION_REMINDER).putExtra("id",id).putExtra("title",item.optString("title"));
        PendingIntent pi=PendingIntent.getBroadcast(context,id.hashCode(),fire,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=23)alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else alarms.set(AlarmManager.RTC_WAKEUP,when,pi);
      }
    }catch(Exception ignored){}
  }
}
