package com.myraa.mobile;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.*;
import android.provider.Settings;
import android.text.TextUtils;
import android.app.Notification;
import android.os.Bundle;
import org.json.*;

public final class NotificationAccessService extends NotificationListenerService {
  public static boolean enabled(Context c) { String flat=Settings.Secure.getString(c.getContentResolver(),"enabled_notification_listeners"); return !TextUtils.isEmpty(flat) && flat.contains(c.getPackageName()+"/"); }
  @Override public void onNotificationPosted(StatusBarNotification sbn) {
    if(sbn==null || sbn.getNotification()==null)return;
    Bundle extras=sbn.getNotification().extras; if(extras==null)return;
    String title=String.valueOf(extras.getCharSequence(Notification.EXTRA_TITLE,""));
    CharSequence body=extras.getCharSequence(Notification.EXTRA_BIG_TEXT); if(body==null)body=extras.getCharSequence(Notification.EXTRA_TEXT);
    String text=body==null?"":body.toString();
    if(title.trim().isEmpty() && text.trim().isEmpty())return;
    try {
      String app=sbn.getPackageName(); try { app=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(app,0)).toString(); } catch(Exception ignored){}
      SharedPreferences p=getSharedPreferences("vishal.jarvis.features",MODE_PRIVATE); JSONArray old=new JSONArray(p.getString("recent_notifications","[]")); JSONArray next=new JSONArray();
      next.put(new JSONObject().put("app",app).put("title",title.substring(0,Math.min(160,title.length()))).put("text",text.substring(0,Math.min(500,text.length()))).put("at",System.currentTimeMillis()));
      for(int i=0;i<old.length() && i<24;i++)next.put(old.get(i)); p.edit().putString("recent_notifications",next.toString()).apply();
    } catch(Exception ignored){}
  }
}
